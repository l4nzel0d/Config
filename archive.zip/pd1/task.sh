#!/bin/sh
cp "$1" biba.txt
exit 0