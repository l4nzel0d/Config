#!/bin/sh
grep -o "^[^:]*" /etc/passwd | sort