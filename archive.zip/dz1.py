from zipfile import ZipFile
import re

ACCEPTED_ARCHIVE_EXTENSION = "zip"

def check_archive_name(file_name):
    pattern = r'^[\w,\s-]+\.' + ACCEPTED_ARCHIVE_EXTENSION + r"$"
    return True if re.match(rf"{pattern}", file_name) else False
    

def main():
    archive_name = ""
    while (True):
        archive_name = input("Input archive name: ")
        if check_archive_name(archive_name):
            break
        print("Invalid name of an archive")

    try:
        with ZipFile(archive_name, 'r') as myzip:
            while True:
                command = input("$ ")
                match command:
                    case "ls":
                        for name in myzip.namelist():
                            print(name)
                    case "exit":
                        break
                    case command.startswith("cat "):
                        path = command.split()[1]
                        content = myzip.read(path).decode()
                        print(content)
                    case _:
                        print("Unknown command")
    except FileNotFoundError:
        print("Archive wasn't found")
    except Exception as e:
        print("An error occured openning archive")

if __name__ == "__main__":
    main()