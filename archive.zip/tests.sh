echo $0
echo $1 $2
echo $#
echo $@